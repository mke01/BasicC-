namespace X
{
	class List
	{};

	class Array
	{};
};

namespace Y
{
	class List
	{};

	class Tree
	{};
};

using namespace X;
using namespace Y;

int main()
{
	Array a;
	Tree t;
	Y::List l;

	return 0;
}
