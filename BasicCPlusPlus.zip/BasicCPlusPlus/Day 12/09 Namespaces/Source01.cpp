int n;

void f()
{
}

int main()
{
	n = 1;
	f();
	return 0;
}

/*
Varaibale such as 'n' and functions such as 'f', 'main'
etc. when defined in this manner are said to be 
belonging to Global Namespace.

Note Global Namespace and Global Data Space are not
same things.
*/