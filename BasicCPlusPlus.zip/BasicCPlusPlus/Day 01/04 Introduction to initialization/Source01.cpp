void main()
{
	int a = 38;
}

// Initialization is an assignment executed at
// the definition of a variable.