void main()
{
	int a;
	a = 38; // This one is an assignment
	// Don't call it as initialization
}