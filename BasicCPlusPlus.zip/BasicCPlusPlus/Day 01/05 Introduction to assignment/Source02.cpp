void main()
{
	float a;
	a = 1.23;
	/* This assignment results into warning,
	because 1.23 is double type and
	c is float type.*/

	float b;
	b = 1.23f;
}