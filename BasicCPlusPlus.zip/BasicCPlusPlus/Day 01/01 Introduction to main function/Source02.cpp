void f()
{
}

// Above program gives error [unresolved external symbol _main].
// This implies that the console application program
// must be written with 'main' function.
