void main()
{
}

void main()
{
}

// Above program gives error ['main' redefinition error].
// This implies that a program must be writtne with
// one and only one definition of 'main' function.