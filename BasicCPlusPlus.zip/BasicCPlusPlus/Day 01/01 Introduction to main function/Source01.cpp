void main()
{
}

// 'main' is known as a function.
// It serves as an entry point to a console application.
// For Windows application an entry point is 'WinMain'.
// An entry point is a location in a program from where
// computer starts executing instructions.
// A program can have one and only one entry point.
// A program can however have one or more exit points.