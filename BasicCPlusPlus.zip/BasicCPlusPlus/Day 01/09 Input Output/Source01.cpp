#include <iostream>
using namespace std;

void main()
{
	int a = 0, b = 0, c = 0;

	cout << "Enter first number: ";
	cin >> a;

	cout << "Enter second number: ";
	cin >> b;

	c = a + b;
	
	cout << "The sum is " << c << endl;
}