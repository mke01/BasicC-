void main()
{
	int a = 1, b = 2, c = 0;

	c = a + b; // addition

	c = a - b; // subtraction

	c = a * b; // multiplication

	c = a / b; // division

	c = a % b; // modulus or remainder
}