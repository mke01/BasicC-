void main()
{
	int a = 1, b = 0;
	
	// pre-increment scenario
	//a = a + 1;
	//b = a;
	b = ++a;

	int c = 1, d = 0;

	// post-increment scenario
	//d = c;
	//c = c + 1;
	d = c++;
}