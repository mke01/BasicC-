void main()
{
	signed int a = -5;
	unsigned int b = 4294967295;
	b = b + 1;
	short int c = -5;
	long int d = -5;
}