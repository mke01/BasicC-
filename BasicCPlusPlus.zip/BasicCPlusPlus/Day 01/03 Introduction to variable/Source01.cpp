void main()
{
	int a;
}

// A variable is a named memory location.