void main()
{
	"C++"; // string constant
}