void main()
{
	'C'; // character constant
}