void main()
{
	3.142857; // double constant
}