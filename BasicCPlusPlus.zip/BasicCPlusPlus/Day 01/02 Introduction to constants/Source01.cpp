void main()
{
	38; // integer constant in decimal numbering system
}