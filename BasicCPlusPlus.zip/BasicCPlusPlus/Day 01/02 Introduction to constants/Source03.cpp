void main()
{
	046; // integer constant in octal numbering system
}