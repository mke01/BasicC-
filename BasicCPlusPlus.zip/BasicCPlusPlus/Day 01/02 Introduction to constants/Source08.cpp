void main()
{
	3.142857f; // float constant
}