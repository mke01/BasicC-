void main()
{
	0x26; // integer constant in hexa-decimal numbering system
}