#if !defined(CONSOLEAPI_H)
#define CONSOLEAPI_H

class ConsoleAPI
{
public:
	static void GotoXY(int x, int y);
};

#endif