int main()
{
	int n[3] = { 1, 2, 3 };
	int m[4];

	int (&a)[3] = n;


	return 0;
}