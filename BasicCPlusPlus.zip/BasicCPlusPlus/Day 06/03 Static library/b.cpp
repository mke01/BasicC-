int min(int a, int b)
{
	return a > b ? a : b;
}

/*
Command to compile cl /c b.cpp
Command to prepare static library is 
lib b.obj OR
lib b.obj /OUT:mylib.lib
*/