int min(int a, int b)
{
	return a < b ? a : b;
}

/*
Command to compile in command shell is 'cl /c b.cpp'.
This prodces a.obj.
*/