int min(int a, int b);

int main()
{
	int u = 1, v = 2, r = 0;
	r = min(6, 3);
	return 0;
}