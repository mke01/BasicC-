void main()
{
	int u = 3;
	int v = 4;
	bool b;
	b = u < v;
	b = u > v;
	b = u != v;
	b = u == v;
	b = u <= v;
	b = u >= v;
}