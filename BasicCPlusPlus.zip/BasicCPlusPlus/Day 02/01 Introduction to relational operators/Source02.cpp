void main()
{
	bool b;
	b = 3 < 4;
	b = 3 > 4;
	b = 3 != 4;
	b = 3 == 4;
	b = 3 <= 4;
	b = 3 >= 4;
}