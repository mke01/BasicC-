void main()
{
	int n = 3;
	bool b = false;
	b = n > 0 && n < 5;
}