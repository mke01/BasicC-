#define N 5

void main()
{
	int n[N] = { 0 };
	for(int i = 0; i < N;n[i] = 7, ++i);
}

/*
Note in above code for loop is iterating null statement.
*/