void main()
{
	int a[5];
	int i = 0;

	while(i < 5)
	{
		a[i] = i + 1;
		++i;
	}
}