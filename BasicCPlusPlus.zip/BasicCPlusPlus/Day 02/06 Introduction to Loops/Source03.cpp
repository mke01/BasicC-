#include <stdio.h>

void main()
{
	int i = 0;

	for(i = 1; i <= 5 ; ++i)
	{
		printf("Hello, World\n");
	}
}