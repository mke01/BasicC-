#define SIZE 5

void main()
{
	int a[SIZE];

	for(int i = 0; i < SIZE; ++i)
	{
		a[i] = i + 1;
	}
}