#include <stdio.h>

void main()
{
	// Infinite loop
	for(;;)
	{
		printf("Hello, World\n");
	}
}