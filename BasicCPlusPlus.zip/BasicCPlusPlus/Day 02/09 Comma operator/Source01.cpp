void main()
{
	int i = 0, j = 0, k = 0;

	i = 1, j = 5, k = 3; // comma operator
	k = 5 - i++;
}

/*
Comma operator is executed from left to right.
*/