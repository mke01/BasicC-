void main()
{
	int a = 4, b = 2, c = 0;
	c = a < b ? a : b;
}