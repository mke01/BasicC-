// Macro Variable
#define N 1
void main()
{
	int n = N;
}