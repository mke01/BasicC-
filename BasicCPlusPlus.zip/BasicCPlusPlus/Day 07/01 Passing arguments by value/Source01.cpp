int f();

int main()
{
	int a = 1;
	f(a);
	return 0;
}

void f(int n)
{
	n = 5;
}