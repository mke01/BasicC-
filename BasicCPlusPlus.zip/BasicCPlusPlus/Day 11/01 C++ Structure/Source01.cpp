struct Integer
{
};

void f()
{
}

int main()
{
	Integer u;
	return 0;
}

/*
Empty structures are not allowed in C language, 
however they're acceptable in C++ language.

The size of empty structure computes to 1 byte.
*/