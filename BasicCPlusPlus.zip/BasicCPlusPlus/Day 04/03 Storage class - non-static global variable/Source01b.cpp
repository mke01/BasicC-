extern int n;

void f()
{
	n = n + 1;
}