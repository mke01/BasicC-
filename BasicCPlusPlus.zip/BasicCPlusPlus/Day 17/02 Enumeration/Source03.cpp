#include<stdio.h>
#include<memory>
void main()
{
	char *p = (char *) malloc(8);
}