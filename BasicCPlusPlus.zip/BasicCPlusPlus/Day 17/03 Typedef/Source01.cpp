#include<windows.h>
typedef int* INT_PTR;

int main()
{
	INT_PTR a, b, c;

	int i=10;
	// HRESULT

	//HMODULE
	return 0;
}