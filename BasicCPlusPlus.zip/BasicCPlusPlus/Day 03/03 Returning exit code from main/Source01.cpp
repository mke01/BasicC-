int main()
{
	return 0;
}

/*
A value returned from main function is known as
exit code.

This code is reported to operating system.

If an application exits with exit code 0, it implies
application was terminated successfully.

If it exits with number other than zero, then
refer its user manual to learn the reason behind
the value returned.
*/