int add(int u, int v)
{
	int w = 0;

	w = u + v;

	return w;
}