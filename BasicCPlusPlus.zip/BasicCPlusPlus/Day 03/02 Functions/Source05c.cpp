#include "functions.h"

int Sub(int u, int v)
{
	int w = 0;

	w = add(u, -v);

	return w;
}