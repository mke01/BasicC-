void main()
{
	int a[5] = { 1, 2, 3, 4, 5 }; // How to initialize array elements
	a[2] = 6; // How to write value into array element
	int n = a[3]; // How to read value from array element
}