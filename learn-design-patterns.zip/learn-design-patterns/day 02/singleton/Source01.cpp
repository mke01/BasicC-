#include <iostream>
using namespace std;

#include "Logger.h"

int main() {
	Logger::GetInstance().Log(10);
	Logger::GetInstance().Log(3.14);
}