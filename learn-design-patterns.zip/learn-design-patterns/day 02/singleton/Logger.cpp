#include <iostream>
using namespace std;

#include "Logger.h"

Logger Logger::m_logger;

void Logger::Log(int data) {
	cout << data << flush;
}

void Logger::Log(double data) {
	cout << data << flush;
}

void Logger::Log(std::string data) {
	cout << data << endl;
}

Logger & Logger::GetInstance() {
	return m_logger;
}
