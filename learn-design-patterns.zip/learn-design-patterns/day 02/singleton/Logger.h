#pragma once

#include <string>

class Logger {
private:
	Logger() {}
	Logger(const Logger &) {}
public:
	void Log(int data);
	void Log(double data);
	void Log(std::string data);
public:
	static Logger& GetInstance();
private:
	static Logger m_logger;
};
