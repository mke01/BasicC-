#include <memory>
using namespace std;

// framwork developer
class Base {
public:
	void Execute() {
		Step1();
		Step2();
		Step3();
		Step4();
		Step5();
	}
private:
	void Step1() {}
	virtual void Step2() {}
	void Step3() {}
	void Step4() {}
	virtual void Step5() {};
};

// application developer
class A : public Base {
private:
	void Step2() {}
	void Step5() {}
};

class B : public Base {
private:
	void Step2() {}
};

int main() {
	unique_ptr<Base> u(new A);
	u->Execute();

	unique_ptr<Base> v(new B);
	v->Execute();
}




