#include <iostream>
using namespace std;

int main() {
	char op;
	double u = 0.0, v = 0.0, result = 0.0;

	cout << "Enter first number: ";
	cin >> u;

	cout << "Enter second number: ";
	cin >> v;

	cout << "Enter operator [+ - * /]: ";
	cin >> op;

	switch (op) {
	case '+':
		result = u + v;
		break;
	case '-':
		result = u - v;
		break;
	case '*':
		result = u * v;
		break;
	case '/':
		result = u / v;
		break;
	case '%':
		result = u % v;
		break;
	default:
		cout << "Invalid operator" << endl;
		goto END;
	}

	cout << "result = " << result << endl;
END:
	return 0;
}