#include <memory>
using namespace std;

#include "adapter.h"

int main() {
	double result = 0.0;
	unique_ptr<IRealCalculator> realCalculator(new RealCalculator);
	result = realCalculator->Add(1.0, 2.0);
	result = realCalculator->Sub(1.0, 2.0);
}


