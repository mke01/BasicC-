#include <memory>
#include <string>
#include <sstream>
#include <assert.h>
#include <iostream>
#include <Windows.h>
using namespace std;

#include "..\adapter\adapter.h"

class RealCalculatorStub {
public:
	RealCalculatorStub() {
		m_hpipe = CreateNamedPipe(TEXT("\\\\.\\pipe\\RealCalculatorServer"),
			PIPE_ACCESS_DUPLEX, PIPE_TYPE_BYTE,
			PIPE_UNLIMITED_INSTANCES, 64, 64, 0, NULL);
	}
	~RealCalculatorStub() {
		CloseHandle(m_hpipe);
	}
public:
	void Run() {
		CHAR buffer[m_size], verb[m_size];
		double u = 0.0, v = 0.0, result = 0.0;
		DWORD bytesToRead = m_size;

		do {
			if (!ReceiveMsg(buffer, bytesToRead)) {
				Sleep(100);
				continue;
			}

			istringstream ss(buffer);
			ss >> verb;

			if (strcmp(verb, "Add") == 0) {
				ss >> u >> v;
				result = m_realCalculator.Add(u, v);
				sprintf_s(buffer, m_size, "%lf", result);
				SendMsg(buffer);
			}
			else if (strcmp(verb, "Sub") == 0) {
				ss >> u >> v;
				result = m_realCalculator.Sub(u, v);
				sprintf_s(buffer, m_size, "%lf", result);
				SendMsg(buffer);
			}
			else if (strcmp(verb, "End") == 0) {
				break;
			}
		} while (1);
	}
private:
	BOOL SendMsg(LPSTR message) {
		assert(message != nullptr);
		DWORD byteToWrite = strlen(message) + 1;
		return WriteFile(m_hpipe, message, byteToWrite, NULL, NULL);
	}
	DWORD ReceiveMsg(LPSTR message, DWORD size) {
		DWORD bytesToRead = size;
		return ReadFile(m_hpipe, message, bytesToRead, NULL, NULL);
	}
private:
	HANDLE m_hpipe;
	RealCalculator m_realCalculator;
private:
	static const size_t m_size = 64;
};

int main() {
	RealCalculatorStub realCalculatorStub;
	realCalculatorStub.Run();
}