int main()
{
	bool srcitizen = true;
	double interestRate;
	if (srcitizen)
	{
		interestRate = 9.5;
	}
	else
		interestRate = 9.0;
}

/*
Instead of doing if else we can use turnary operator

: double interestRate = srcitizen ? 9.5 : 9.0;
*/