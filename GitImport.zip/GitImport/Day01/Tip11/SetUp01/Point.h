#pragma once
class Point {};