#pragma once

class Circle
{
private:
	Point m_center;
	unsigned m_r;

};