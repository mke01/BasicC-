#include <cstring>

int main()
{
	const int size = 30;
	char a[size] ;
	strcat_s(a, size, "Hi");
}