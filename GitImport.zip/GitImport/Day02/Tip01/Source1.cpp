int main()
{
	int i = 1;
	int j = 0;

	j = ++i;
	j = i++;
	
}