class A {

public:
	A() {}
	~A() {}
};

class B {

public:
	B() {}
	~B() {}
};

int main()
{
	A a;
	B b;
}